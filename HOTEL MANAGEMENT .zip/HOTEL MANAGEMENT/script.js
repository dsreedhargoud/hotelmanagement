document.addEventListener('DOMContentLoaded', () => {
  const yearNode = document.getElementById('year');
  if (yearNode) {
    yearNode.textContent = new Date().getFullYear();
  }

  const form = document.querySelector('form');
  const notice = document.querySelector('.notice');
  if (form && notice) {
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      notice.textContent = 'Thank you! Your request has been received. Our team will contact you shortly.';
      notice.classList.add('show');
      form.reset();
    });
  }
});
